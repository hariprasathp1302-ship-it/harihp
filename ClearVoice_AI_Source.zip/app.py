import os
import uuid
import uuid
import logging
from typing import Optional
from datetime import datetime, timedelta

from fastapi import FastAPI, File, UploadFile, Form, BackgroundTasks, HTTPException, Depends, status
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, EmailStr
import librosa
import soundfile as sf
import noisereduce as nr
import numpy as np
import scipy.signal
import subprocess

# DB and Auth mapping 
import sqlite3
import bcrypt
import jwt

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="AI Noise Cancellation API")

# Allow CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Static file serving
UPLOAD_DIR = "uploads"
PROCESSED_DIR = "processed"
DB_FILE = "users.db"

os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(PROCESSED_DIR, exist_ok=True)

app.mount("/static", StaticFiles(directory="static"), name="static")

# ------ AUTHENTICATION SETUP ------ #
SECRET_KEY = "super-secret-clearvoice-ai-key-do-not-share"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24 * 7 # 1 week

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="api/login")

def init_db():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL,
            hashed_password TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    conn.close()

init_db()

# Models
class UserCreate(BaseModel):
    email: EmailStr
    password: str

class Token(BaseModel):
    access_token: str
    token_type: str

# Auth Helpers
def verify_password(plain_password: str, hashed_password: str):
    return bcrypt.checkpw(plain_password.encode('utf-8'), hashed_password.encode('utf-8'))

def get_password_hash(password: str):
    salt = bcrypt.gensalt()
    return bcrypt.hashpw(password.encode('utf-8'), salt).decode('utf-8')

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

def get_current_user(token: str = Depends(oauth2_scheme)):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        email: str = payload.get("sub")
        if email is None:
            raise credentials_exception
    except jwt.PyJWTError:
        raise credentials_exception
    
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute("SELECT email FROM users WHERE email=?", (email,))
    user = cursor.fetchone()
    conn.close()
    
    if user is None:
        raise credentials_exception
    return user[0] # return email

# ------ API ENDPOINTS ------ #

@app.post("/api/register")
async def register(user: UserCreate):
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    # Check if user exists
    cursor.execute("SELECT id FROM users WHERE email=?", (user.email,))
    if cursor.fetchone():
        conn.close()
        raise HTTPException(status_code=400, detail="Email already registered")
        
    hashed_pw = get_password_hash(user.password)
    try:
        cursor.execute("INSERT INTO users (email, hashed_password) VALUES (?, ?)", (user.email, hashed_pw))
        conn.commit()
    except sqlite3.IntegrityError:
        pass
    finally:
        conn.close()
        
    # Auto-login to generate token directly upon registration
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user.email}, expires_delta=access_token_expires
    )
    return {"access_token": access_token, "token_type": "bearer"}

@app.post("/api/login", response_model=Token)
async def login(form_data: OAuth2PasswordRequestForm = Depends()):
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute("SELECT hashed_password FROM users WHERE email=?", (form_data.username,))
    row = cursor.fetchone()
    conn.close()
    
    if not row or not verify_password(form_data.password, row[0]):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
        
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": form_data.username}, expires_delta=access_token_expires
    )
    return {"access_token": access_token, "token_type": "bearer"}

@app.get("/api/me")
async def read_users_me(current_user: str = Depends(get_current_user)):
    return {"email": current_user}

@app.get("/")
async def serve_index():
    return FileResponse("static/index.html")

def remove_file(filepath: str):
    try:
        if os.path.exists(filepath):
            os.remove(filepath)
            logger.info(f"Deleted file {filepath}")
    except Exception as e:
        logger.error(f"Error deleting file {filepath}: {e}")

@app.post("/api/process")
async def process_audio(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    strength: float = Form(1.0),
    echo_removal: bool = Form(False),
    voice_clarity: bool = Form(False),
    current_user: str = Depends(get_current_user)
):
    import subprocess
    input_filepath = None
    temp_wav_path = None
    
    try:
        # Save uploaded file
        file_ext = os.path.splitext(file.filename)[1]
        if file_ext == "":
            file_ext = ".wav" # default fallback
        
        file_id = str(uuid.uuid4())
        input_filepath = os.path.join(UPLOAD_DIR, f"{file_id}_in{file_ext}")
        temp_wav_path = os.path.join(UPLOAD_DIR, f"{file_id}_temp.wav")
        
        with open(input_filepath, "wb") as buffer:
            buffer.write(await file.read())
            
        logger.info(f"Received file: {file.filename}, extracting audio via FFmpeg.")
        
        # 0. Convert/Extract to WAV using subprocess ffmpeg
        try:
            subprocess.run([
                'ffmpeg', '-y', '-i', input_filepath, 
                '-acodec', 'pcm_s16le',
                temp_wav_path
            ], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        except subprocess.CalledProcessError as e:
            logger.error(f"FFmpeg extraction failed: {e.stderr.decode()}")
            raise Exception("Failed to extract audio from the uploaded file.")
            
        logger.info(f"Audio extracted successfully, processing with strength {strength}")
        
        # Load the clean wav audio using librosa
        y, sr = librosa.load(temp_wav_path, sr=None, mono=False)
        
        # 1. AI Noise Cancellation (using noisereduce package)
        # Using stationary=False adapts to dynamic noise like wind, talking in background, etc.
        # It's generally better for real-world recordings.
        reduced_noise = nr.reduce_noise(y=y, sr=sr, prop_decrease=strength, stationary=False)
        
        # 2. Advanced Audio Enhancements
        processed_y = reduced_noise
        
        if voice_clarity:
            # Simple high-pass filter
            sos = scipy.signal.butter(10, 150, 'hp', fs=sr, output='sos')
            processed_y = scipy.signal.sosfilt(sos, processed_y)
            processed_y = processed_y * 1.2
            
        # Normalize volume gently but only if it's too quiet or clipping
        max_val = np.max(np.abs(processed_y))
        if max_val > 0.0:
            processed_y = processed_y / max_val * 0.95
        
        # Save Processed Audio temp
        temp_clean_wav = os.path.join(UPLOAD_DIR, f"{file_id}_clean.wav")
        sf.write(temp_clean_wav, processed_y.T if processed_y.ndim > 1 else processed_y, sr)
        
        is_video = file_ext.lower() in ['.mp4', '.mov', '.mkv', '.avi', '.webm']
        
        if is_video:
            output_filename = f"processed_{file_id}.mp4"
            output_filepath = os.path.join(PROCESSED_DIR, output_filename)
            try:
                # Merge original video with new audio (High audio bitrate, Exact Original Video)
                subprocess.run([
                    'ffmpeg', '-y', '-i', input_filepath, '-i', temp_clean_wav,
                    '-c:v', 'copy', '-c:a', 'aac', '-b:a', '320k', '-map', '0:v:0', '-map', '1:a:0',
                    output_filepath
                ], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            except subprocess.CalledProcessError as e:
                logger.error(f"FFmpeg muxing failed: {e.stderr.decode()}")
                raise Exception("Failed to merge the cleaned audio back into the video.")
        else:
            output_filename = f"processed_{file_id}.wav"
            output_filepath = os.path.join(PROCESSED_DIR, output_filename)
            os.rename(temp_clean_wav, output_filepath)
        
        # Schedule cleanup
        background_tasks.add_task(remove_file, input_filepath)
        background_tasks.add_task(remove_file, temp_wav_path)
        if is_video:
             background_tasks.add_task(remove_file, temp_clean_wav)
        
        return JSONResponse({
            "status": "success",
            "message": "Audio processed successfully",
            "original_filename": file.filename,
            "processed_file_url": f"/api/download/{output_filename}"
        })
        
    except Exception as e:
        logger.error(f"Error processing audio: {str(e)}")
        # Cleanup on failure
        if input_filepath: background_tasks.add_task(remove_file, input_filepath)
        if temp_wav_path: background_tasks.add_task(remove_file, temp_wav_path)
        return JSONResponse({"status": "error", "message": str(e)}, status_code=500)

@app.get("/api/download/{filename}")
async def download_file(background_tasks: BackgroundTasks, filename: str):
    file_path = os.path.join(PROCESSED_DIR, filename)
    if os.path.exists(file_path):
        # We also want to auto-delete after download, wait: file response keeps the file handle open
        # We can use a background task with delay, or just let users download it multiple times. 
        return FileResponse(file_path, media_type='audio/wav', filename=filename)
    return JSONResponse({"status": "error", "message": "File not found"}, status_code=404)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app:app", host="127.0.0.1", port=8000, reload=True)
