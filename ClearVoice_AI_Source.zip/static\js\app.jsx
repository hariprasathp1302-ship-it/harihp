const { useState, useEffect, useRef, useCallback } = React;

function App() {
  const [file, setFile] = useState(null);
  const [isDragging, setIsDragging] = useState(false);
  
  // Auth State
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem('cv_auth_token') || null);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authMode, setAuthMode] = useState('login'); // 'login' or 'register'
  const [authError, setAuthError] = useState(null);
  const [authForm, setAuthForm] = useState({ email: '', password: '' });
  
  // Processing State
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [processedUrl, setProcessedUrl] = useState(null);
  const [errorStatus, setErrorStatus] = useState(null);
  
  // Settings
  const [strength, setStrength] = useState(1.0);
  const [echoRemoval, setEchoRemoval] = useState(false);
  const [voiceClarity, setVoiceClarity] = useState(false);
  
  // WaveSurfer Audio Refs
  const originalWaveRef = useRef(null);
  const processedWaveRef = useRef(null);
  const originalWsRef = useRef(null);
  const processedWsRef = useRef(null);
  const originalVideoRef = useRef(null);
  const processedVideoRef = useRef(null);
  const [isVideo, setIsVideo] = useState(false);

  const [isPlayingOriginal, setIsPlayingOriginal] = useState(false);
  const [isPlayingProcessed, setIsPlayingProcessed] = useState(false);

  // Initial Auth Check
  useEffect(() => {
      if (token) {
          fetch('/api/me', {
              headers: { 'Authorization': `Bearer ${token}` }
          })
          .then(res => {
              if (res.ok) return res.json();
              throw new Error('Invalid token');
          })
          .then(data => setUser(data))
          .catch(() => handleLogout());
      }
  }, [token]);
  
  const handleAuthSubmit = async (e) => {
      e.preventDefault();
      setAuthError(null);
      
      const endpoint = authMode === 'login' ? '/api/login' : '/api/register';
      const body = authMode === 'login' 
          ? new URLSearchParams({ username: authForm.email, password: authForm.password }) // OAuth2 requirement
          : JSON.stringify({ email: authForm.email, password: authForm.password }); // Pydantic model
          
      const headers = authMode === 'login' 
          ? { 'Content-Type': 'application/x-www-form-urlencoded' }
          : { 'Content-Type': 'application/json' };
          
      try {
          const res = await fetch(endpoint, {
              method: 'POST',
              headers,
              body
          });
          
          const data = await res.json();
          if (!res.ok) throw new Error(data.detail || 'Authentication failed');
          
          setToken(data.access_token);
          localStorage.setItem('cv_auth_token', data.access_token);
          setShowAuthModal(false);
          setAuthForm({email: '', password: ''});
      } catch (err) {
          setAuthError(err.message);
      }
  };
  
  const handleLogout = () => {
      setUser(null);
      setToken(null);
      localStorage.removeItem('cv_auth_token');
  };

  // Drag and Drop Handlers
  const handleDragOver = (e) => {
    e.preventDefault();
    setIsDragging(true);
  };
  
  const handleDragLeave = () => {
    setIsDragging(false);
  };
  
  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileSelect(e.dataTransfer.files[0]);
    }
  };

  const handleFileInput = (e) => {
    if (e.target.files && e.target.files[0]) {
      handleFileSelect(e.target.files[0]);
    }
  };

  const handleFileSelect = (selectedFile) => {
    // Check if it's an audio or video file
    const isVidType = selectedFile.type.startsWith('video/');
    if (selectedFile.type.startsWith('audio/') || isVidType) {
      setFile(selectedFile);
      setProcessedUrl(null);
      setErrorStatus(null);
      setIsVideo(isVidType);
      
      // Initialize Original WaveSurfer
      setTimeout(() => {
        if (originalWsRef.current) {
          originalWsRef.current.destroy();
        }
        
        try {
          const ws = WaveSurfer.create({
            container: originalWaveRef.current,
            waveColor: '#4f46e5',
            progressColor: '#818cf8',
            cursorColor: '#c7d2fe',
            barWidth: 2,
            barGap: 1,
            barRadius: 2,
            height: 80,
            normalize: true,
            media: isVidType ? originalVideoRef.current : null,
          });
          
          ws.loadBlob(selectedFile);
          ws.on('finish', () => setIsPlayingOriginal(false));
          originalWsRef.current = ws;
        } catch(e) {
             console.error("WaveSurfer error", e);
        }
      }, 100);

    } else {
      setErrorStatus("Please upload a valid audio or video file.");
    }
  };

  const handleProcess = async () => {
    if (!file) return;
    
    setIsProcessing(true);
    setProgress(10);
    setErrorStatus(null);
    setProcessedUrl(null);
    
    const formData = new FormData();
    formData.append('file', file);
    formData.append('strength', strength);
    formData.append('echo_removal', echoRemoval);
    formData.append('voice_clarity', voiceClarity);
    
    // Simulate initial progress
    const progressInterval = setInterval(() => {
        setProgress(p => (p < 85 ? p + 5 : p));
    }, 600);
    
    try {
      const response = await fetch('/api/process', {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${token}`
        },
        body: formData,
      });
      
      clearInterval(progressInterval);
      setProgress(100);
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.message || 'Error processing file');
      }
      
      setProcessedUrl(data.processed_file_url);
      
      // Load processed audio waveform
      setTimeout(() => {
        if (processedWsRef.current) {
          processedWsRef.current.destroy();
        }
        
        const ws = WaveSurfer.create({
          container: processedWaveRef.current,
          waveColor: '#10b981', // emerald
          progressColor: '#34d399',
          cursorColor: '#a7f3d0',
          barWidth: 2,
          barGap: 1,
          barRadius: 2,
          height: 80,
          normalize: true,
          media: isVideo ? processedVideoRef.current : null,
        });
        
        ws.load(data.processed_file_url);
        ws.on('finish', () => setIsPlayingProcessed(false));
        processedWsRef.current = ws;
      }, 100);
      
    } catch (error) {
      clearInterval(progressInterval);
      console.error(error);
      setErrorStatus(error.message);
    } finally {
      setIsProcessing(false);
    }
  };

  const toggleOriginalPlayback = () => {
    if (originalWsRef.current) {
      originalWsRef.current.playPause();
      setIsPlayingOriginal(originalWsRef.current.isPlaying());
    }
  };

  const toggleProcessedPlayback = () => {
    if (processedWsRef.current) {
      processedWsRef.current.playPause();
      setIsPlayingProcessed(processedWsRef.current.isPlaying());
    }
  };
  
  const handleReset = () => {
      setFile(null);
      setProcessedUrl(null);
      setErrorStatus(null);
      setProgress(0);
  }

  return (
    <div className="min-h-screen text-slate-200 flex flex-col pt-6 pb-12 px-4 sm:px-6 lg:px-8">
      {/* Navbar */}
      <header className="max-w-6xl mx-auto w-full flex justify-between items-center mb-12">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center shadow-lg shadow-indigo-500/20">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
            </svg>
          </div>
          <h1 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-white to-slate-400">ClearVoice AI</h1>
        </div>
        <div className="flex items-center gap-4">
            <a href="#" className="text-sm font-medium text-slate-400 hover:text-white transition-colors">Documentation</a>
            <div className="h-8 w-[1px] bg-slate-800"></div>
            {user ? (
                <div className="flex items-center gap-4">
                    <span className="text-sm text-indigo-300 font-medium truncate max-w-[150px]">{user.email}</span>
                    <button onClick={handleLogout} className="px-4 py-2 text-sm font-semibold text-white bg-slate-800 hover:bg-slate-700 rounded-lg border border-slate-700 transition">Log Out</button>
                </div>
            ) : (
                <>
                    <button onClick={() => {setAuthMode('login'); setShowAuthModal(true)}} className="px-4 py-2 text-sm font-semibold text-white bg-slate-800 hover:bg-slate-700 rounded-lg border border-slate-700 transition">Log In</button>
                    <button onClick={() => {setAuthMode('register'); setShowAuthModal(true)}} className="px-4 py-2 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg shadow-lg shadow-indigo-500/20 transition">Signup Free</button>
                </>
            )}
        </div>
      </header>
      
      {/* Auth Modal overlay */}
      {showAuthModal && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
              <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-md shadow-2xl overflow-hidden animate-fade-in-up">
                  <div className="p-6">
                      <div className="flex justify-between items-center mb-6">
                          <h3 className="text-xl font-bold">{authMode === 'login' ? 'Welcome Back' : 'Create an Account'}</h3>
                          <button onClick={() => setShowAuthModal(false)} className="text-slate-400 hover:text-white">
                              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                          </button>
                      </div>
                      
                      {authError && (
                          <div className="mb-4 bg-red-500/10 border border-red-500/30 text-red-400 p-3 rounded-lg text-sm">
                              {authError}
                          </div>
                      )}
                      
                      <form onSubmit={handleAuthSubmit} className="space-y-4">
                          <div>
                              <label className="block text-sm font-medium text-slate-300 mb-1">Email</label>
                              <input 
                                  type="email" 
                                  required
                                  value={authForm.email}
                                  onChange={e => setAuthForm({...authForm, email: e.target.value})}
                                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-4 py-2.5 outline-none focus:border-indigo-500 transition text-white" 
                                  placeholder="you@example.com"
                              />
                          </div>
                          <div>
                              <label className="block text-sm font-medium text-slate-300 mb-1">Password</label>
                              <input 
                                  type="password" 
                                  required
                                  value={authForm.password}
                                  onChange={e => setAuthForm({...authForm, password: e.target.value})}
                                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-4 py-2.5 outline-none focus:border-indigo-500 transition text-white" 
                                  placeholder="••••••••"
                              />
                          </div>
                          
                          <button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-semibold py-3 rounded-lg mt-2 shadow-lg shadow-indigo-500/20 transition">
                              {authMode === 'login' ? 'Log In' : 'Sign Up'}
                          </button>
                      </form>
                      
                      <div className="mt-6 text-center text-sm text-slate-400">
                          {authMode === 'login' ? "Don't have an account? " : "Already have an account? "}
                          <button onClick={() => {setAuthMode(authMode === 'login' ? 'register' : 'login'); setAuthError(null);}} className="text-indigo-400 hover:text-indigo-300 font-medium">
                              {authMode === 'login' ? 'Sign up' : 'Log in'}
                          </button>
                      </div>
                  </div>
              </div>
          </div>
      )}

      {/* Main Content */}
      <main className="max-w-4xl mx-auto w-full flex-grow flex flex-col gap-6">
        
        {/* Header Text */}
        <div className="text-center mb-6">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">Studio-Quality Sound in Seconds.</h2>
            <p className="text-lg text-slate-400 max-w-2xl mx-auto">Remove background noise, echo, and enhance voice clarity instantly using advanced AI models directly in your browser.</p>
        </div>

        {/* Studio Box */}
        <div className="glass-panel rounded-2xl p-6 md:p-8 relative overflow-hidden">
          
          {!file && (
              // Drag & Drop Upload State
              <div 
                className={`border-2 border-dashed rounded-xl p-12 text-center transition-all ${isDragging ? 'border-indigo-500 bg-indigo-500/10' : 'border-slate-700 hover:border-slate-600 bg-slate-800/50'}`}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={(e) => {
                    if (!user) {
                        e.preventDefault();
                        setIsDragging(false);
                        setShowAuthModal(true);
                        return;
                    }
                    handleDrop(e);
                }}
              >
                <div className="w-16 h-16 mx-auto bg-slate-800 rounded-full flex items-center justify-center mb-4 border border-slate-700 shadow-xl">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-indigo-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                    </svg>
                </div>
                <h3 className="text-xl font-semibold mb-2">Drag & drop your file here</h3>
                <p className="text-slate-400 text-sm mb-6">Supports MP3, WAV, M4A, MP4 (Up to 500MB)</p>
                
                {user ? (
                    <label className="cursor-pointer bg-white text-slate-900 px-6 py-3 rounded-lg font-medium hover:bg-slate-200 transition shadow-lg inline-flex items-center gap-2">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-11a1 1 0 10-2 0v2H7a1 1 0 100 2h2v2a1 1 0 102 0v-2h2a1 1 0 100-2h-2V7z" clipRule="evenodd" />
                        </svg>
                        Browse Files
                        <input type="file" className="hidden" accept="audio/*,video/*" onChange={handleFileInput} />
                    </label>
                ) : (
                    <button 
                        onClick={() => setShowAuthModal(true)}
                        className="bg-indigo-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-indigo-500 transition shadow-lg shadow-indigo-500/20 inline-flex items-center gap-2"
                    >
                        Sign in to Upload
                    </button>
                )}
              </div>
          )}

          {errorStatus && (
              <div className="bg-red-900/40 border border-red-500/50 text-red-200 px-4 py-3 rounded-lg mb-6 flex items-start gap-3">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mt-0.5 text-red-400 flex-shrink-0" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                  </svg>
                  <div>
                      <h4 className="font-medium">Processing Error</h4>
                      <p className="text-sm opacity-90">{errorStatus}</p>
                  </div>
              </div>
          )}

          {file && (
            <div className="space-y-8 animate-fade-in-up">
              
              {/* Top Bar with file name */}
              <div className="flex items-center justify-between border-b border-slate-700/50 pb-4">
                  <div className="flex items-center gap-3">
                      <div className="p-2 bg-slate-800 rounded-lg border border-slate-700">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-indigo-400" viewBox="0 0 20 20" fill="currentColor">
                            <path fillRule="evenodd" d="M9.383 3.076A1 1 0 0110 4v12a1 1 0 01-1.707.707L4.586 13H2a1 1 0 01-1-1V8a1 1 0 011-1h2.586l3.707-3.707a1 1 0 011.09-.217zM14.657 2.929a1 1 0 011.414 0A9.972 9.972 0 0119 10a9.972 9.972 0 01-2.929 7.071 1 1 0 01-1.414-1.414A7.971 7.971 0 0017 10c0-2.21-.894-4.208-2.343-5.657a1 1 0 010-1.414zm-2.829 2.828a1 1 0 011.415 0A5.983 5.983 0 0115 10a5.984 5.984 0 01-1.757 4.243 1 1 0 01-1.415-1.415A3.984 3.984 0 0013 10a3.983 3.983 0 00-1.172-2.828 1 1 0 010-1.415z" clipRule="evenodd" />
                          </svg>
                      </div>
                      <div>
                          <h3 className="font-semibold text-white">{file.name}</h3>
                          <p className="text-xs text-slate-400">{(file.size / (1024 * 1024)).toFixed(2)} MB • {file.type || 'Audio'}</p>
                      </div>
                  </div>
                  
                  <button onClick={handleReset} className="text-slate-400 hover:text-white transition p-2 hover:bg-slate-800 rounded-lg">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                      </svg>
                  </button>
              </div>

              {/* Layout Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  
                  {/* Left Column: Settings */}
                  <div className="lg:col-span-1 space-y-6">
                      <h4 className="text-sm font-semibold uppercase tracking-wider text-slate-400">Enhancement Settings</h4>
                      
                      {/* Strength Slider */}
                      <div className="space-y-3">
                          <div className="flex justify-between items-center">
                              <label className="text-sm font-medium">Noise Reduction Strength</label>
                              <span className="text-xs font-mono bg-indigo-500/20 text-indigo-300 px-2 py-1 rounded">{(strength * 100).toFixed(0)}%</span>
                          </div>
                          <input 
                              type="range" 
                              min="0" max="1" step="0.05" 
                              value={strength}
                              onChange={(e) => setStrength(parseFloat(e.target.value))}
                              disabled={isProcessing}
                              className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-indigo-500"
                          />
                      </div>

                      {/* Toggles */}
                      <div className="space-y-4">
                          <label className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition ${voiceClarity ? 'border-indigo-500 bg-indigo-500/10' : 'border-slate-700 hover:border-slate-600 bg-slate-800/30'} ${isProcessing ? 'opacity-50 cursor-not-allowed' : ''}`}>
                              <input 
                                  type="checkbox" 
                                  checked={voiceClarity}
                                  onChange={(e) => setVoiceClarity(e.target.checked)}
                                  disabled={isProcessing}
                                  className="w-5 h-5 rounded border-slate-600 text-indigo-600 focus:ring-indigo-600 bg-slate-700"
                              />
                              <div>
                                  <div className="text-sm font-medium text-white">Voice Isolation</div>
                                  <div className="text-xs text-slate-400">Boost vocal frequencies</div>
                              </div>
                          </label>

                          <label className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition ${echoRemoval ? 'border-indigo-500 bg-indigo-500/10' : 'border-slate-700 hover:border-slate-600 bg-slate-800/30'} ${isProcessing ? 'opacity-50 cursor-not-allowed' : ''}`}>
                              <input 
                                  type="checkbox" 
                                  checked={echoRemoval}
                                  onChange={(e) => setEchoRemoval(e.target.checked)}
                                  disabled={isProcessing}
                                  className="w-5 h-5 rounded border-slate-600 text-indigo-600 focus:ring-indigo-600 bg-slate-700"
                              />
                              <div>
                                  <div className="text-sm font-medium text-white">De-Reverb</div>
                                  <div className="text-xs text-slate-400">Reduce room echo</div>
                              </div>
                          </label>
                      </div>

                      {!processedUrl && (
                          <button 
                              onClick={handleProcess}
                              disabled={isProcessing}
                              className={`w-full py-4 px-6 rounded-xl font-semibold text-white transition shadow-lg flex items-center justify-center gap-2
                                  ${isProcessing ? 'bg-indigo-600/50 cursor-not-allowed' : 'bg-indigo-600 hover:bg-indigo-500 shadow-indigo-500/25'}
                              `}
                          >
                              {isProcessing ? (
                                  <>
                                      <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                      </svg>
                                      Processing Engine... {progress}%
                                  </>
                              ) : (
                                  <>
                                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                                        <path fillRule="evenodd" d="M11.3 1.046A1 1 0 0112 2v5h4a1 1 0 01.82 1.573l-7 10A1 1 0 018 18v-5H4a1 1 0 01-.82-1.573l7-10a1 1 0 011.12-.381z" clipRule="evenodd" />
                                      </svg>
                                      Enhance Audio
                                  </>
                              )}
                          </button>
                      )}
                      
                      {processedUrl && (
                           <div className="flex flex-col gap-3">
                               <a 
                                  href={processedUrl}
                                  download={`Cleaned_${file.name}`}
                                  className="w-full py-3 px-6 rounded-xl font-semibold text-slate-900 bg-emerald-400 hover:bg-emerald-300 transition shadow-lg shadow-emerald-500/25 flex items-center justify-center gap-2"
                              >
                                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                                    <path fillRule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clipRule="evenodd" />
                                  </svg>
                                  Download HD Audio
                              </a>
                              <button 
                                onClick={handleReset}
                                className="w-full py-3 px-6 rounded-xl font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 transition"
                              >
                                  Process Another File
                              </button>
                           </div>
                      )}
                  </div>

                  {/* Right Column: Visualizer */}
                  <div className="lg:col-span-2 space-y-6">
                      
                      {/* Original Track */}
                      <div className="bg-slate-900/50 border border-slate-700/50 rounded-xl p-5 relative">
                          <div className="flex items-center justify-between mb-4">
                              <div className="flex items-center gap-2 text-sm font-medium text-indigo-300">
                                  <div className="w-2 h-2 rounded-full bg-indigo-400"></div>
                                  Original Unprocessed
                              </div>
                              <button 
                                onClick={toggleOriginalPlayback}
                                className="w-8 h-8 rounded-full bg-indigo-600 hover:bg-indigo-500 flex items-center justify-center text-white transition shadow-lg shadow-indigo-600/30"
                              >
                                  {isPlayingOriginal ? (
                                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zM7 8a1 1 0 012 0v4a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v4a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" /></svg>
                                  ) : (
                                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-0.5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" /></svg>
                                  )}
                              </button>
                          </div>
                          {isVideo && file && (
                              <video 
                                  ref={originalVideoRef} 
                                  src={URL.createObjectURL(file)} 
                                  className="w-full h-auto rounded-lg mb-4 bg-black max-h-[300px]" 
                                  playsInline
                              ></video>
                          )}
                          {/* Waveform container */}
                          <div ref={originalWaveRef} className="w-full h-[80px]"></div>
                      </div>

                      {/* Processed Track */}
                      {isProcessing && (
                          <div className="bg-slate-900/50 border border-emerald-900/50 rounded-xl p-5 flex flex-col items-center justify-center h-[160px]">
                              <div className="w-12 h-12 relative flex items-center justify-center mb-4">
                                  <div className="w-full h-full border-4 border-slate-700/30 border-t-emerald-500 rounded-full animate-spin"></div>
                              </div>
                              <p className="font-medium text-emerald-400">Applying AI Models...</p>
                              <div className="w-64 h-1.5 bg-slate-800 rounded-full mt-3 overflow-hidden">
                                  <div className="h-full bg-emerald-500 rounded-full transition-all duration-300 ease-out" style={{ width: `${progress}%` }}></div>
                              </div>
                          </div>
                      )}

                      {processedUrl && (
                          <div className="bg-slate-900/50 border border-emerald-500/30 rounded-xl p-5 relative shadow-[0_0_15px_rgba(16,185,129,0.1)]">
                              <div className="flex items-center justify-between mb-4">
                                  <div className="flex items-center gap-2 text-sm font-medium text-emerald-400">
                                      <div className="w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)]"></div>
                                      Cleaned Audio
                                  </div>
                                  <button 
                                    onClick={toggleProcessedPlayback}
                                    className="w-8 h-8 rounded-full bg-emerald-500 hover:bg-emerald-400 flex items-center justify-center text-slate-900 transition shadow-lg shadow-emerald-500/30"
                                  >
                                      {isPlayingProcessed ? (
                                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zM7 8a1 1 0 012 0v4a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v4a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" /></svg>
                                      ) : (
                                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-0.5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" /></svg>
                                      )}
                                  </button>
                              </div>
                              {isVideo && processedUrl && (
                                <video 
                                    ref={processedVideoRef} 
                                    src={processedUrl} 
                                    className="w-full h-auto rounded-lg mb-4 bg-black max-h-[300px]" 
                                    playsInline
                                ></video>
                              )}
                              {/* Waveform container */}
                              <div ref={processedWaveRef} className="w-full h-[80px]"></div>
                          </div>
                      )}

                  </div>
              </div>

            </div>
          )}

        </div>
        
        {/* Features list */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
            <div className="glass-panel p-5 rounded-xl border-t border-indigo-500/30">
                <h4 className="font-semibold text-white mb-2 ml-1 flex items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-indigo-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                    AI Deep Denoise
                </h4>
                <p className="text-sm text-slate-400">Our deep learning model automatically identifies and eliminates wind, fan, HVAC, and street noise.</p>
            </div>
            <div className="glass-panel p-5 rounded-xl border-t border-purple-500/30">
                <h4 className="font-semibold text-white mb-2 ml-1 flex items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-purple-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" /></svg>
                    Voice Isolation
                </h4>
                <p className="text-sm text-slate-400">Proprietary dynamic EQ enhances your vocals to sound crisp, clear, and professional.</p>
            </div>
            <div className="glass-panel p-5 rounded-xl border-t border-pink-500/30">
                <h4 className="font-semibold text-white mb-2 ml-1 flex items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-pink-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg>
                    Secure Processing
                </h4>
                <p className="text-sm text-slate-400">Your files are processed directly on memory and instantly deleted after download ensuring full privacy.</p>
            </div>
        </div>

      </main>
      
      {/* Footer */}
      <footer className="mt-16 text-center text-sm text-slate-500">
        &copy; 2026 ClearVoice AI Studio by Antigravity. All rights reserved.
      </footer>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
