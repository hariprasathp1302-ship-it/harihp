# Premium Online Video Editor

This project is a full-stack web application for professional video editing, similar to CapCut, Premiere Pro, or DaVinci Resolve.

## Technology Stack
- Frontend: React.js, Tailwind CSS
- Backend: Node.js, FFmpeg

## Features
- Media library (file upload: MP4, MOV, AVI, MKV, MP3, WAV, JPG, PNG)
- Video preview player
- Drag-and-drop timeline editor (multi-layer: video, audio, text, effects)
- Video editing tools (crop, rotate, resize, speed, reverse, frame adjustment)
- Filters/effects (cinematic, vintage, B&W, color grading, blur, brightness, contrast, saturation)
- Audio tools (noise removal, clarity, equalizer, volume, fade)
- Text/titles (overlays, fonts, animated, subtitle generator)
- Transitions (fade, slide, zoom, blur)
- AI features (noise cancellation, enhancement, subtitle, scene detection)
- Export system (720p, 1080p, 2K, 4K, MP4, MOV, download)
- Auto-save, smooth rendering, dark theme professional UI

## Project Structure
- `client/` — React frontend
- `server/` — Node.js backend
